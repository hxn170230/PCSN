make;
./q_simulator < input.in | tee avg_output;
python3 plotter.py
